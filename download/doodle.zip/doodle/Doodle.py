from customtkinter import *
from tkinter import colorchooser
from tkinter.colorchooser import askcolor
from tkinter import filedialog
from PIL import Image, ImageDraw, ImageTk, ImageGrab
from tkinter.filedialog import askdirectory
from CTkMessagebox import CTkMessagebox
from CTkToolTip import *
import customtkinter
from CTkMenuBar import *
import customtkinter as ctk
from tkinter import ttk
from ColorRangeSelector import ColorRangeSelector
from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk
from tktooltip import ToolTip


# Тема приложения
customtkinter.set_appearance_mode("dark")  # Modes: "System" (standard), "Dark", "Light"
# Цвет кнопок
customtkinter.set_default_color_theme("dark-blue")  # Themes: "blue" (standard), "green", "dark-blue"


# Определение класса и конструктора программы
class Peinterest(customtkinter.CTk):
    DEFAULT_PEN_SIZE = 5.0
    DEFAULT_COLOR = 'black'

    # Создание модуля
    def __init__(self):
        super().__init__()

        # На кнопку закрытия вылазит меню которое спрашивает хочет ли пользователь закрыть программу
        def on_closing():
            msg = CTkMessagebox(title="Выйти?", message="Вы точно хотите выйти?",
                                icon="question", option_1="Отмена", option_2="Нет", option_3="Да")
            response = msg.get()

            if response == "Да":
                self.destroy()
            else:
                print("Нажмите Да чтобы закрыть!")

        # Название программы
        self.title('Doodle')
        # Дополнительная функция для закрытия
        self.protocol('WM_DELETE_WINDOW', on_closing)

        self.iconbitmap('Res/dudl.ico')
        # Что бы на главном экране были меню
        self.draw_menu()
        self.menu_bar()
        self.right_menu()
        # Геометрия
        self.geometry('1920x1080')
        # Полотно
        self.background_color = 'white'
        self.canvas_width = 1600
        self.canvas_height = 980
        self.canvas = ctk.CTkCanvas(self, width=self.canvas_width, height=self.canvas_height, bg="white")
        self.canvas.place(x=50, y=28)
        # Механика для рисования
        self.setup()
        # Курсор
        self.canvas.configure(cursor="crosshair")

    # Дополнительное окно
    def Settings_window(self):
        settings_win = CTkToplevel(self)  # Создание дополнительного окна
        settings_win.title('Настройки')  # Имя
        settings_win.geometry('300x130')  # Размеры окна
        settings_win.attributes("-topmost", True)  # Окно поверх все всегда
        settings_win.resizable(False, False)  # Фиксированный размер
        # Название с "Настройками"
        name_button = customtkinter.CTkLabel(settings_win, text='Настройки:')
        name_button.place(x=115, y=5)
        # Название с "Темами"
        theme_button = customtkinter.CTkLabel(settings_win, text='Темы:')
        theme_button.place(x=131, y=40)
        # Окно где можно менять темы
        self.appearance_mode_optionemenu = customtkinter.CTkOptionMenu(settings_win,
                                                                       values=["Dark", "Light", "System"],
                                                                       command=self.change_appearance_mode_event,
                                                                       text_color='#F4BB44',
                                                                       fg_color='grey6',
                                                                       button_color='grey3', button_hover_color='grey1')
        self.appearance_mode_optionemenu.place(x=80, y=70)

    new_window_open = False

    # Функция для смены темы
    def change_appearance_mode_event(self, new_appearance_mode: str):
        customtkinter.set_appearance_mode(new_appearance_mode)

    #Меню справа
    def right_menu(self):
        #Само меню
        self.merth = customtkinter.CTkFrame(self, width=50, height=1080)
        self.merth.place(x=0, y=28)

        self.img1 = Image.open("Res/ruchka.png")
        self.img2 = ImageTk.PhotoImage(self.img1)

        self.pen_button = Button(self.merth, image=self.img2, command=self.use_pen,
                                 background='grey8',
                                 activebackground='grey8', border=1)
        self.pen_button.place(x=5, y=20)

        ToolTip(self.pen_button, msg='Ручка', bg='black', fg='white', delay=0)

        img1_1 = Image.open("Res/kist_35_na_35.png")
        self.img2_1 = ImageTk.PhotoImage(img1_1)

        self.brush_button = Button(self.merth, image=self.img2_1,command=self.use_brush,
                                   background='grey8',
                                 activebackground='grey8', border=1)
        self.brush_button.place(x=5, y=75)

        ToolTip(self.brush_button, msg='Кисть', bg='black', fg='white', delay=0)

        img1_2 = Image.open("Res/lastik.png")
        self.img2_2 = ImageTk.PhotoImage(img1_2)

        self.eraser_button = Button(self.merth, image=self.img2_2, command=self.use_eraser,
                                 background='grey8',
                                 activebackground='grey8', border=1)
        self.eraser_button.place(x=5, y=130)

        ToolTip(self.eraser_button, msg='Ластик', bg='black', fg='white', delay=0)

        img1_3 = Image.open("Res/lastik (1).png")
        self.img2_3 = ImageTk.PhotoImage(img1_3)

        self.clear_button = Button(self.merth, image=self.img2_3,command=self.clear_canvas,
                                 background='grey8',
                                 activebackground='grey8', border=1)
        self.clear_button.place(x=5, y=185)

        ToolTip(self.clear_button, msg='Очистить\nхолст', bg='black', fg='white', delay=0)

        img1_4 = Image.open("Res/shesterenka.png")
        self.img2_4 = ImageTk.PhotoImage(img1_4)

        self.seting_button = Button(self.merth, image=self.img2_4, command=self.Settings_window,
                                    background='grey8',
                                 activebackground='grey8', border=1)
        self.seting_button.place(x=5, y=920)

        ToolTip(self.seting_button, msg='Настройки', bg='black', fg='white', delay=0)

    # Боковое меню
    def menu_bar(self):
        # Меню
        self.checkbox_frame = customtkinter.CTkFrame(self, width=300, height=1080)
        self.checkbox_frame.place(x=1650, y=28)
        # Название менюшки
        self.name = CTkLabel(self.checkbox_frame, text='Размер кисти и ластика:',
                             text_color='grey', font=('Times', 19))
        self.name.place(x=40, y=410)

        # Кнопка дял изменение цвета кисти си ручки
        self.color_button = customtkinter.CTkButton(self.checkbox_frame, text='Применить цвет', command=self.choose_color,
                                                    text_color='#F4BB44', fg_color='grey8', border_color='black',
                                                    hover_color='grey4', border_width=2)
        self.color_button.place(x=65, y=265)

        ToolTip(self.color_button, msg='Применить\nцвет', bg='black', fg='white', delay=0)

        self.colors_button = customtkinter.CTkButton(self.checkbox_frame, text='Выбор цвета', command=self.chooses_color,
                                                    text_color='#F4BB44', fg_color='grey8', border_color='black',
                                                    hover_color='grey4', border_width=2)
        self.colors_button.place(x=65, y=335)

        ToolTip(self.colors_button, msg='Выбор\nцвета', bg='black', fg='white', delay=0)

        # Кнопка для слайдера и чтобы у него показывались цифры
        self.choose_size_button = customtkinter.CTkSlider(self.checkbox_frame, from_=0, to=100, command=self.show_value,
                                                          fg_color='grey8',
                                                          border_color='black', button_color='#F4BB44',
                                                          button_hover_color='#f49901', border_width=2, width=190)
        self.choose_size_button.place(x=45, y=450)
        self.tooltip_1 = CTkToolTip(self.choose_size_button, message="50")  # Это чтобы показывались цифры
        # Кнопка для изменения темы
        self.appearance_mode_optionemenu = customtkinter.CTkOptionMenu(self.checkbox_frame,
                                                                       values=["Dark", "Light", "System"],
                                                                       command=self.themeses, text_color='#F4BB44',
                                                                       fg_color='grey6',
                                                                       button_color='grey3', button_hover_color='grey1')
        self.appearance_mode_optionemenu.place(x=65, y=930)

        ToolTip(self.appearance_mode_optionemenu, msg='Выбор\nтемы', bg='black', fg='white', delay=0)

        self.selector2 = ColorRangeSelector(self.checkbox_frame, 20, 20)

    # Здесь находятся очень много функций для рисования, использование ластика, цвета, на какую кнопку можно рисовать
    def setup(self):
        self.old_x = None
        self.old_y = None
        self.line_width = self.choose_size_button.get()
        self.color = self.DEFAULT_COLOR
        self.eraser_on = False
        self.active_button = self.pen_button
        self.canvas.bind('<B1-Motion>', self.paint)
        self.canvas.bind('<ButtonRelease-1>', self.reset)

    # Функция для изменения темы
    def themeses(self, new_appearance_mode: str):
        customtkinter.set_appearance_mode(new_appearance_mode)

    # Чтобы показывались цифры на слайдере
    def show_value(self, value):
        self.tooltip_1.configure(message=int(value))

    # Использование ручки
    def use_pen(self):
        self.canvas.configure(cursor="crosshair")
        self.activate_button(self.pen_button)

    # Использование кисти
    def use_brush(self):
        self.canvas.configure(cursor="diamond_cross")
        self.activate_button(self.brush_button)

    # Использование ластика кго механика
    def use_eraser(self):
        self.canvas.configure(cursor='circle')
        self.color = self.background_color

    def chooses_color(self):  # смена цвета
        self.eraser_on = False
        self.color = askcolor(color=self.color)[1]

    # Выбор цвета для рисования
    def choose_color(self):  # смена цвета
        self.eraser_on = False
        self.color = self.selector2.result

    # Активация кнопки
    def activate_button(self, some_button, eraser_mode=False):
        self.active_button.configure()
        some_button.configure()
        self.active_button = some_button
        self.eraser_on = eraser_mode

    # Механика рисования
    def paint(self, event):
        self.line_width = self.choose_size_button.get()
        paint_color = 'white' if self.eraser_on else self.color  # ластик
        if self.old_x and self.old_y:
            self.canvas.create_line(self.old_x, self.old_y, event.x, event.y,
                                    width=self.line_width, fill=paint_color,
                                    capstyle=ROUND, smooth=TRUE, splinesteps=36)
        self.old_x = event.x
        self.old_y = event.y

    # Чтобы можно было рисовать без этого оно не работает что оно снова могло рисовать
    def reset(self, event):
        self.old_x, self.old_y = None, None

    # Механика создания заднего фона
    def change_background(self):
        color = colorchooser.askcolor(title='Цвет заднего фона')
        if color[1]:
            self.background_color = color[1]
            self.canvas.configure(bg=self.background_color)

    # Верхне меню второе под потолком
    def draw_menu(self):
        menu = CTkMenuBar(master=self)  # bg_color='grey12'
        # Кнопка "Файл"
        button_1 = menu.add_cascade("Файл", text_color='#F4BB44', fg_color='grey8', hover_color='grey4',
                                    border_color='black', border_width=2)
        # Кнопка "Рисование"
        button_2 = menu.add_cascade("Рисование", text_color='#F4BB44', fg_color='grey8', hover_color='grey4',
                                    border_color='black', border_width=2)
        # Кнопка "Цвет"
        button_3 = menu.add_cascade("Цвет", text_color='#F4BB44', fg_color='grey8', hover_color='grey4',
                                    border_color='black', border_width=2)
        # Кнопка "Работа с файлом"
        button_4 = menu.add_cascade("Работа с файлом", text_color='#F4BB44', fg_color='grey8', hover_color='grey4',
                                    border_color='black', border_width=2)
        # Кнопка "Очистить лист"
        button_5 = menu.add_cascade("Очистить лист", text_color='#F4BB44', fg_color='grey8', hover_color='grey4',
                                    border_color='black', border_width=2)

        # Кнопка "О программе"
        dropdown1 = CustomDropdownMenu(widget=button_1, bg_color='grey5', fg_color='grey10', text_color='#DAA520',
                                       hover_color='grey6', corner_radius=0)
        dropdown1.add_option(option="О программе", command=self.version, border_color='black', border_width=2)
        dropdown1.add_separator()

        dropdown1.add_option(option="Настройки", command=self.Settings_window, border_color='black', border_width=2)
        dropdown1.add_separator()
        # Кнопка "Выхода"
        dropdown1.add_option(option="Выход", command=self.exit, border_color='black', border_width=2)

        # Кнопка "Ручка"
        dropdown2 = CustomDropdownMenu(widget=button_2, bg_color='grey5', fg_color='grey10', text_color='#DAA520',
                                       hover_color='grey6', corner_radius=0)
        dropdown2.add_option(option="Ручка", command=self.use_pen, border_color='black', border_width=2)
        dropdown2.add_separator()
        # Кнопка "Кисть"
        dropdown2.add_option(option="Кисть", command=self.use_brush, border_color='black', border_width=2)
        dropdown2.add_separator()
        # Кнопка "Ластик"
        dropdown2.add_option(option="Ластик", command=self.use_eraser, border_color='black', border_width=2)
        dropdown2.add_separator()

        # Кнопка "Фигуры"
        sub_menu = dropdown2.add_submenu("Фигуры                            >", border_color='black',
                                         border_width=2)
        sub_menu.add_option(option="Квадрат", command=self.v_razrabotke, border_color='black', border_width=2)
        sub_menu.add_separator()
        # Кнопка "Круг"
        sub_menu.add_option(option="Круг", command=self.v_razrabotke, border_color='black', border_width=2)
        sub_menu.add_separator()
        # Кнопка "Треугольник"
        sub_menu.add_option(option="Треугольник", command=self.v_razrabotke, border_color='black', border_width=2)
        sub_menu.add_separator()
        # Кнопка "Прямая линия"
        sub_menu.add_option(option="Прямая линия", command=self.v_razrabotke, border_color='black', border_width=2)

        # Кнопка "Цвета кисти"
        dropdown3 = CustomDropdownMenu(widget=button_3, bg_color='grey5', fg_color='grey10', text_color='#F4BB44',
                                       hover_color='grey6', corner_radius=0)
        dropdown3.add_option(option="Цвет кисть", command=self.choose_color, border_color='black', border_width=2)
        dropdown3.add_separator()
        # Кнопка "Цвета заднего фона"
        dropdown3.add_option(option="Цвет заднего фона", command=self.change_background, border_color='black',
                             border_width=2)

        # Кнопка "Сохранить изображение"
        dropdown4 = CustomDropdownMenu(widget=button_4, bg_color='grey5', fg_color='grey10', text_color='#F4BB44',
                                       hover_color='grey6', corner_radius=0)
        dropdown4.add_option(option="Сохранение изображения", command=self.save_image, border_color='black',
                             border_width=2)
        dropdown4.add_separator()
        # Кнопка "Открыть изображение"
        dropdown4.add_option(option="Открытие изображения", command=self.open_image, border_color='black',
                             border_width=2)

        # Кнопка "Очистить лист"
        dropdown5 = CustomDropdownMenu(widget=button_5, bg_color='grey5', fg_color='grey10', text_color='#F4BB44',
                                       hover_color='grey6', corner_radius=0)
        dropdown5.add_option(option="Очистить лист", command=self.clear_canvas, border_color='black', border_width=2)


    # Механика кнопки выхода
    def exit(self):
        msg = CTkMessagebox(title="Выйти?", message="Вы точно хотите выйти?",
                            icon="question", option_1="Отмена", option_2="Нет", option_3="Да")
        response = msg.get()

        if response == "Да":
            self.destroy()
        else:
            print("Click 'Yes' to exit!")

    # Открывает меню в котором написана версия программы
    def version(self):
        CTkMessagebox(title="Версия",
                      message="2.3.6.13.15 Версия\n\nСоздатель: Гордеев Даниил\n\nАвтор идеи: Просекова Владислава")  # 1 масштабные

    # Открывает меню настроек
    def settings(self):
        CTkMessagebox(title="Настройки", message="В разработке",
                      option_1="Выйти", option_3="Применить")

    # Механика очистки всего холста кроме заднего фона
    def clear_canvas(self):
        self.canvas.delete("all")

    # Всплывающее окно "В разработке"
    def v_razrabotke(self):
        CTkMessagebox(title="Фигуры в разработке", message='в разработке')

    # Механика для сохранения изображения
    def save_image(self):
        directory = askdirectory(title="Выберите папку для сохранения")
        if directory:
            x = self.winfo_rootx() + self.canvas.winfo_x()
            y = self.winfo_rooty() + self.canvas.winfo_y()
            x1 = x + self.canvas.winfo_width()
            y1 = y + self.canvas.winfo_height()
            ImageGrab.grab().crop((x, y, x1, y1)).save(f"{directory}/drawing.png", "PNG")
            CTkMessagebox(title="Изображение сохранено", message="Изображение сохранено",
                          icon="check", option_1="Закрыть")
            print("Изображение сохранено!")

    # Код для открытия изображений(не работает)
    def open_image(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
        if file_path:
            image = Image.open(file_path)
            image = image.resize((self.canvas_width, self.canvas_height))
            draw = ImageDraw.Draw(image)
            self.canvas.delete("all")
            self.canvas.image = ImageTk.PhotoImage(image)
            self.canvas.create_image(0, 0, anchor="nw", image=self.canvas.image)
            CTkMessagebox(title="Изображение открыто", message="Изображение открыто",
                          icon="check", option_1="Закрыть")


# Конец
if __name__ == "__main__":
    app = Peinterest()
    app.mainloop()