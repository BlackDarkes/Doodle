import tkinter as tk

root = tk.Tk()


# Загрузка изображения с прозрачным фоном
image = tk.PhotoImage(file="kist_35_na_35.png")

# Создание кнопки с прозрачным фоном
button = tk.Button(root, image=image, borderwidth=0, highlightthickness=0, command=lambda: print("Clicked!"))
button.pack()

root.mainloop()